package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;

public class Fly extends Module {
    public final Setting<Double> speed = register(new Setting<>("Speed", 0.5, 0.1, 3.0));

    public Fly() { super("Fly", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        double sp = speed.get();
        float f = p.input.movementForward, s = p.input.movementSideways;
        double x = 0, z = 0, yaw = Math.toRadians(p.getYaw());
        if (f != 0 || s != 0) {
            double len = Math.hypot(f, s);
            f /= len; s /= len;
            x = (-Math.sin(yaw) * f + Math.cos(yaw) * s) * sp;
            z = (Math.cos(yaw) * f + Math.sin(yaw) * s) * sp;
        }
        double y = p.input.jumping ? sp : p.input.sneaking ? -sp : 0;
        p.setVelocity(x, y, z);
    }
}
