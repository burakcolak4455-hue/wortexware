package dev.thunder.client.gui;

public class Theme {
    public static final int BG        = 0xE6141418;
    public static final int HEADER    = 0xF01C1C23;
    public static final int ROW_HOVER = 0x22FFFFFF;
    public static final int SETTING   = 0x40000000;
    public static final int OFF       = 0xFF3A3A44;
    public static final int TEXT      = 0xFFFFFFFF;
    public static final int TEXT_DIM  = 0xFF9A9AA8;
    public static final int ACCENT_A  = 0xFF8A5CFF; // mor
    public static final int ACCENT_B  = 0xFF4FA3FF; // mavi

    /** Zamanla akan gradient aksan rengi; offset ile her satira farkli ton */
    public static int accent(int offset) {
        double t = (System.currentTimeMillis() / 1000.0 + offset * 0.15);
        float f = (float) ((Math.sin(t) + 1) / 2);
        return RenderUtil.lerp(ACCENT_A, ACCENT_B, f);
    }
}
