package dev.thunder.client.module;

import dev.thunder.client.gui.RenderUtil;
import dev.thunder.client.gui.Theme;
import dev.thunder.client.module.impl.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new ClickGui());
        modules.add(new Aura());
        modules.add(new ElytraTarget());
        modules.add(new ElytraHelper());
        modules.add(new ElytraBooster());
        modules.add(new Sprint());
        modules.add(new Fly());
        modules.add(new Step());
        modules.add(new NoFall());
        // Yeni modulleri buraya ekle
    }

    public Module get(String name) {
        return modules.stream().filter(m -> m.name.equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public void onKey(int key, int action) {
        if (action != 1 || key == -1) return;
        if (MinecraftClient.getInstance().currentScreen != null) return;
        for (Module m : modules) if (m.getKey() == key) m.toggle();
    }

    public void onTick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    public void onRender2D(DrawContext ctx) {
        var mc = MinecraftClient.getInstance();
        var tr = mc.textRenderer;

        // Watermark: yuvarlak hap seklinde
        String user = mc.getSession().getUsername();
        String wm = "Wortex§7Ware §8| §f" + user + " §8| §f" + mc.getCurrentFps() + " fps";
        int ww = tr.getWidth(wm) + 14;
        RenderUtil.rect(ctx, 4, 4, ww, 16, 5, Theme.BG);
        ctx.fill(8, 5, 4 + ww - 4, 6, Theme.accent(0));
        ctx.drawText(tr, wm, 11, 8, Theme.accent(0), false);

        // ArrayList: sag ust, hizali, solda aksan cubugu
        List<Module> on = modules.stream().filter(m -> m.isEnabled())
                .sorted(Comparator.comparingInt((Module m) -> tr.getWidth(m.name)).reversed()).toList();
        int sw = mc.getWindow().getScaledWidth();
        int y = 4, i = 0;
        for (Module m : on) {
            int w = tr.getWidth(m.name) + 10;
            int x = sw - w - 4;
            int col = Theme.accent(i);
            RenderUtil.rect(ctx, x, y, w, 12, 3, Theme.BG);
            ctx.fill(x, y + 2, x + 2, y + 10, col);
            ctx.drawText(tr, m.name, x + 6, y + 2, col, false);
            y += 14; i++;
        }
        for (Module m : on) m.onRender2D(ctx);
    }
}
