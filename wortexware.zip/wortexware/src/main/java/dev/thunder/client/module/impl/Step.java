package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.attribute.EntityAttributes;

public class Step extends Module {
    public final Setting<Double> height = register(new Setting<>("Height", 2.0, 0.6, 5.0));

    public Step() { super("Step", Category.MOVEMENT); }

    @Override
    public void onTick() { set(height.get()); }

    @Override
    protected void onDisable() { set(0.6); }

    private void set(double v) {
        if (mc.player == null) return;
        var attr = mc.player.getAttributeInstance(EntityAttributes.GENERIC_STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(v);
    }
}
