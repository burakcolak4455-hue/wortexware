package dev.thunder.client.command;

import dev.thunder.client.ThunderClient;
import dev.thunder.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class CommandManager {
    public static final String PREFIX = ".";

    /** true donerse mesaj sunucuya gonderilmez */
    public boolean handle(String msg) {
        if (!msg.startsWith(PREFIX)) return false;
        String[] a = msg.substring(PREFIX.length()).trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) return true;

        switch (a[0].toLowerCase()) {
            case "toggle", "t" -> {
                Module m = a.length > 1 ? ThunderClient.modules.get(a[1]) : null;
                if (m == null) info("Kullanim: .toggle <modul>");
                else { m.toggle(); info(m.name + (m.isEnabled() ? " acildi" : " kapandi")); }
            }
            case "bind" -> {
                Module m = a.length > 2 ? ThunderClient.modules.get(a[1]) : null;
                if (m == null) { info("Kullanim: .bind <modul> <tus>"); break; }
                int key = keyOf(a[2]);
                m.setKey(key);
                info(m.name + " bind: " + a[2].toUpperCase());
            }
            case "config" -> {
                if (a.length > 1 && a[1].equalsIgnoreCase("load")) { dev.thunder.client.config.Config.load(); info("Config yuklendi"); }
                else { dev.thunder.client.config.Config.save(); info("Config kaydedildi"); }
            }
            case "set" -> {
                Module m = a.length > 3 ? ThunderClient.modules.get(a[1]) : null;
                if (m == null) { info("Kullanim: .set <modul> <ayar> <deger>"); break; }
                for (var st : m.settings) if (st.name.equalsIgnoreCase(a[2])) { setValue(st, a[3]); info(st.name + " = " + st.get()); }
            }
            case "friend", "f" -> {
                if (a.length < 2) { info("Kullanim: .friend add|del <isim> | list"); break; }
                var fr = dev.thunder.client.module.impl.Aura.FRIENDS;
                switch (a[1].toLowerCase()) {
                    case "add" -> { if (a.length > 2) { fr.add(a[2].toLowerCase()); info(a[2] + " arkadas eklendi"); } }
                    case "del" -> { if (a.length > 2) { fr.remove(a[2].toLowerCase()); info(a[2] + " silindi"); } }
                    default -> info("Arkadaslar: " + (fr.isEmpty() ? "yok" : String.join(", ", fr)));
                }
            }
            case "list" -> ThunderClient.modules.modules.forEach(m ->
                    info((m.isEnabled() ? "[+] " : "[-] ") + m.name));
            default -> info("Komutlar: .toggle .bind .set .config .friend .list");
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    private static void setValue(dev.thunder.client.setting.Setting<?> s, String v) {
        try {
            Object cur = s.get();
            if (cur instanceof Boolean) ((dev.thunder.client.setting.Setting<Boolean>) s).set(Boolean.parseBoolean(v));
            else if (cur instanceof Double) ((dev.thunder.client.setting.Setting<Double>) s).set(Double.parseDouble(v));
            else if (cur instanceof Integer) ((dev.thunder.client.setting.Setting<Integer>) s).set(Integer.parseInt(v));
        } catch (NumberFormatException ignored) {}
    }

    private static int keyOf(String n) {
        n = n.toUpperCase();
        if (n.equals("NONE")) return -1;
        if (n.length() == 1) return n.charAt(0);
        return switch (n) {
            case "RSHIFT" -> GLFW.GLFW_KEY_RIGHT_SHIFT; case "LSHIFT" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "RCTRL" -> GLFW.GLFW_KEY_RIGHT_CONTROL; case "LALT" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "UP" -> GLFW.GLFW_KEY_UP; case "DOWN" -> GLFW.GLFW_KEY_DOWN;
            case "LEFT" -> GLFW.GLFW_KEY_LEFT; case "RIGHT" -> GLFW.GLFW_KEY_RIGHT;
            default -> -1;
        };
    }

    public static void info(String s) {
        var hud = MinecraftClient.getInstance().inGameHud;
        if (hud != null) hud.getChatHud().addMessage(Text.literal("§b[" + ThunderClient.NAME + "] §f" + s));
    }
}
