package dev.thunder.client;

import dev.thunder.client.command.CommandManager;
import dev.thunder.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

public class ThunderClient implements ClientModInitializer {
    public static final String NAME = "WortexWare";
    public static final MinecraftClient mc = MinecraftClient.getInstance();
    public static ModuleManager modules;
    public static CommandManager commands;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        commands = new CommandManager();
        dev.thunder.client.config.Config.load();
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING
                .register(c -> dev.thunder.client.config.Config.save());

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (dev.thunder.client.module.impl.ClickGui.openRequested && c.currentScreen == null) {
                dev.thunder.client.module.impl.ClickGui.openRequested = false;
                c.setScreen(new dev.thunder.client.gui.ClickGuiScreen());
            }
            if (c.player != null && c.world != null) modules.onTick();
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> modules.onRender2D(ctx));
    }
}
