package dev.thunder.client.mixin;

import dev.thunder.client.ThunderClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ChatMixin {
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void thunder$onChat(String content, CallbackInfo ci) {
        if (ThunderClient.commands != null && ThunderClient.commands.handle(content)) ci.cancel();
    }
}
