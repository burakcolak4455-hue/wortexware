package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

public class Aura extends Module {
    /** .friend add/del ile yonetilir, Aura bunlara vurmaz */
    public static final Set<String> FRIENDS = new HashSet<>();

    public final Setting<Double> range     = register(new Setting<>("Range", 3.0, 2.0, 6.0));
    public final Setting<Double> fov       = register(new Setting<>("FOV", 360.0, 30.0, 360.0));
    public final Setting<Double> turnSpeed = register(new Setting<>("TurnSpeed", 70.0, 5.0, 180.0));
    public final Setting<Double> predict   = register(new Setting<>("Predict", 1.0, 0.0, 5.0));
    public final Setting<Double> delay     = register(new Setting<>("Delay", 0.0, 0.0, 500.0)); // ms
    public final Setting<Boolean> players  = register(new Setting<>("Players", true));
    public final Setting<Boolean> mobs     = register(new Setting<>("Mobs", false));
    public final Setting<Boolean> lowHp    = register(new Setting<>("LowHealthFirst", false));
    public final Setting<Boolean> sticky   = register(new Setting<>("Sticky", true));
    public final Setting<Boolean> rotate   = register(new Setting<>("Rotate", true));
    public final Setting<Boolean> walls    = register(new Setting<>("ThroughWalls", false));
    public final Setting<Boolean> crits    = register(new Setting<>("FallCrits", false));

    private LivingEntity target;
    private long lastHit;

    public Aura() { super("Aura", Category.COMBAT); }

    @Override
    protected void onDisable() { target = null; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (p.isUsingItem() || p.isSpectator()) return;

        if (target != null && (!sticky.get() || !valid(target))) target = null;
        if (target == null) target = pick();
        if (target == null) return;

        // Rotasyon (yumusak, TurnSpeed ile sinirli)
        float yawDiff = 0, pitchDiff = 0;
        if (rotate.get()) {
            Vec3d to = aimPoint(target).subtract(p.getEyePos());
            float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0);
            float wantPitch = (float) MathHelper.clamp(-Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z))), -90, 90);
            float max = turnSpeed.get().floatValue();
            p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - p.getYaw()), -max, max));
            p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(wantPitch - p.getPitch(), -max, max), -90f, 90f));
            yawDiff = Math.abs(MathHelper.wrapDegrees(wantYaw - p.getYaw()));
            pitchDiff = Math.abs(wantPitch - p.getPitch());
            if (yawDiff > 12f || pitchDiff > 12f) return; // henuz hedefe donmedi, vurma
        }

        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;
        // Kritik: havadaysa yukselirken vurma, dusmeyi bekle
        if (crits.get() && !p.isOnGround() && p.fallDistance <= 0f && !p.isTouchingWater() && !p.isClimbing()) return;

        if (System.currentTimeMillis() - lastHit < delay.get()) return;
        lastHit = System.currentTimeMillis();

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    /** Hedefe gercek mesafe: goz -> hitbox'in en yakin noktasi */
    private double reach(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        Vec3d c = new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX),
                MathHelper.clamp(eye.y, b.minY, b.maxY), MathHelper.clamp(eye.z, b.minZ, b.maxZ));
        return eye.distanceTo(c);
    }

    private Vec3d aimPoint(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        Vec3d vel = e.getPos().subtract(new Vec3d(e.prevX, e.prevY, e.prevZ));
        double y = MathHelper.clamp(eye.y, b.minY + 0.3, b.maxY - 0.1);
        return new Vec3d(b.getCenter().x, y, b.getCenter().z).add(vel.multiply(predict.get()));
    }

    private boolean valid(LivingEntity e) {
        var p = mc.player;
        if (e == p || !e.isAlive() || e.isRemoved() || e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity pl) {
            if (!players.get() || pl.isSpectator()) return false;
            if (FRIENDS.contains(pl.getName().getString().toLowerCase())) return false;
        } else if (!mobs.get()) return false;

        if (reach(e) > range.get()) return false;
        if (!walls.get() && !p.canSee(e)) return false;

        if (fov.get() < 360.0) {
            Vec3d to = aimPoint(e).subtract(p.getEyePos());
            float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0);
            if (Math.abs(MathHelper.wrapDegrees(wantYaw - p.getYaw())) > fov.get() / 2.0) return false;
        }
        return true;
    }

    private LivingEntity pick() {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(le)) continue;
            double score = lowHp.get() ? le.getHealth() + le.getAbsorptionAmount() : reach(le);
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }
}
