package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class Aura extends Module {
    public final Setting<Double> range = register(new Setting<>("Range", 3.0, 1.0, 6.0));
    public final Setting<Boolean> players = register(new Setting<>("Players", true));
    public final Setting<Boolean> mobs = register(new Setting<>("Mobs", false));
    public final Setting<Boolean> rotate = register(new Setting<>("Rotate", true));

    public Aura() { super("Aura", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            boolean isPlayer = e instanceof PlayerEntity;
            if (isPlayer ? !players.get() : !mobs.get()) continue;
            double d = p.distanceTo(e);
            if (d <= range.get() && d < best) { best = d; target = le; }
        }
        if (target == null) return;

        if (rotate.get()) {
            Vec3d to = target.getPos().add(0, target.getHeight() / 2.0, 0).subtract(p.getEyePos());
            p.setYaw((float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0));
            p.setPitch((float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z))));
        }

        if (p.getAttackCooldownProgress(0.5f) >= 1.0f) {
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
