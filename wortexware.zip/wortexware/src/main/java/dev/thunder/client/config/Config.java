package dev.thunder.client.config;

import com.google.gson.*;
import dev.thunder.client.ThunderClient;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    private static final Path DIR = FabricLoader.getInstance().getGameDir().resolve("wortexware");
    private static final Path FILE = DIR.resolve("config.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ThunderClient.modules.modules) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.getKey());
                JsonObject st = new JsonObject();
                for (Setting<?> s : m.settings) {
                    Object v = s.get();
                    if (v instanceof Boolean b) st.addProperty(s.name, b);
                    else if (v instanceof Number n) st.addProperty(s.name, n);
                }
                o.add("settings", st);
                root.add(m.name, o);
            }
            Files.createDirectories(DIR);
            Files.writeString(FILE, GSON.toJson(root));
        } catch (Exception e) { e.printStackTrace(); }
    }

    @SuppressWarnings("unchecked")
    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : ThunderClient.modules.modules) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject st = o.getAsJsonObject("settings");
                    for (Setting<?> s : m.settings) {
                        if (!st.has(s.name)) continue;
                        Object cur = s.get();
                        if (cur instanceof Boolean) ((Setting<Boolean>) s).set(st.get(s.name).getAsBoolean());
                        else if (cur instanceof Double) ((Setting<Double>) s).set(st.get(s.name).getAsDouble());
                        else if (cur instanceof Integer) ((Setting<Integer>) s).set(st.get(s.name).getAsInt());
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean() && !m.name.equals("ClickGui"))
                    m.setEnabled(true);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
