package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;

public class ElytraHelper extends Module {
    public final Setting<Boolean> takeoff = register(new Setting<>("AutoTakeoff", true));
    public final Setting<Boolean> firework = register(new Setting<>("AutoFirework", true));
    public final Setting<Double> minSpeed = register(new Setting<>("MinSpeed", 0.9, 0.2, 2.0));
    public final Setting<Double> delay = register(new Setting<>("Delay", 30.0, 5.0, 100.0));

    private int cooldown;

    public ElytraHelper() { super("ElytraHelper", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
        if (cooldown > 0) cooldown--;

        // Havadayken otomatik elytra ac (vanilla'daki ikinci ziplama mantigi)
        if (takeoff.get() && !p.isFallFlying() && !p.isOnGround() && p.getVelocity().y < 0) {
            if (p.checkFallFlying())
                p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        }

        // Hiz dusunce hotbar'daki roketi kullan
        if (firework.get() && p.isFallFlying() && cooldown == 0
                && p.getVelocity().horizontalLength() < minSpeed.get()) {
            int slot = -1;
            for (int i = 0; i < 9; i++)
                if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) { slot = i; break; }
            if (slot == -1) return;

            int old = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.getInventory().selectedSlot = old;
            cooldown = delay.get().intValue();
        }
    }
}
