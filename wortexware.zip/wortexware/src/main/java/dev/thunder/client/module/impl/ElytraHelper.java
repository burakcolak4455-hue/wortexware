package dev.thunder.client.module.impl;

import dev.thunder.client.command.CommandManager;
import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public class ElytraHelper extends Module {
    public final Setting<Boolean> autoSwap    = register(new Setting<>("AutoSwap", true));      // gogusluk <-> elytra
    public final Setting<Boolean> autoOpen    = register(new Setting<>("AutoOpen", true));      // yuksekten dusunce ac
    public final Setting<Double> openHeight   = register(new Setting<>("OpenFallDist", 3.0, 2.0, 20.0));
    public final Setting<Boolean> autoFirework = register(new Setting<>("AutoFirework", true));
    public final Setting<Boolean> invFirework  = register(new Setting<>("InvFirework", true)); // envanterden roket al
    public final Setting<Boolean> launchBoost  = register(new Setting<>("LaunchBoost", true)); // kalkista roket
    public final Setting<Double> minSpeed     = register(new Setting<>("MinSpeed", 0.9, 0.2, 2.0));
    public final Setting<Double> fwDelay      = register(new Setting<>("FireworkDelay", 30.0, 5.0, 100.0)); // tick
    public final Setting<Boolean> saveElytra   = register(new Setting<>("SaveElytra", true));
    public final Setting<Double> minDurability = register(new Setting<>("MinDurability", 15.0, 1.0, 100.0));

    private int cooldown, swapCd, groundTicks;
    private boolean wasFlying, warned;

    public ElytraHelper() { super("ElytraHelper", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (cooldown > 0) cooldown--;
        if (swapCd > 0) swapCd--;
        groundTicks = p.isOnGround() ? groundTicks + 1 : 0;

        ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
        boolean chestElytra = chest.isOf(Items.ELYTRA);
        boolean flying = p.isFallFlying();

        // --- Dayaniklilik korumasi: yipranan elytrayi cikar
        if (saveElytra.get() && chestElytra && !flying && remaining(chest) <= minDurability.get()) {
            if (!warned) { CommandManager.info("Elytra cok yipranmis!"); warned = true; }
            if (autoSwap.get() && swapCd == 0 && p.isOnGround()) swapChest(findChestplate());
        }
        if (!chestElytra || remaining(chest) > minDurability.get()) warned = false;

        // --- AutoSwap: havadayken elytraya, yerde gogusluge gec
        if (autoSwap.get() && swapCd == 0 && mc.currentScreen == null) {
            if (!chestElytra && !p.isOnGround() && !flying
                    && ((p.input.jumping && p.getVelocity().y < 0) || p.fallDistance > openHeight.get())) {
                int slot = findElytra();
                if (slot != -1) swapChest(slot);
            } else if (chestElytra && !flying && groundTicks > 10) {
                int slot = findChestplate();
                if (slot != -1) swapChest(slot);
            }
        }

        chestElytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);

        // --- AutoOpen: yuksekten dusuyorsan elytrayi ac (dusme hasarini onler)
        if (autoOpen.get() && chestElytra && !flying && !p.isOnGround()
                && p.getVelocity().y < 0 && p.fallDistance > openHeight.get()) {
            if (p.checkFallFlying())
                p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        }

        // --- Kalkista bir roket
        if (launchBoost.get() && flying && !wasFlying && autoFirework.get()) {
            if (useRocket()) cooldown = fwDelay.get().intValue();
        }
        wasFlying = flying;

        // --- Hiz dusunce roket
        if (autoFirework.get() && flying && cooldown == 0
                && p.getVelocity().horizontalLength() < minSpeed.get()) {
            if (useRocket()) cooldown = fwDelay.get().intValue();
        }
    }

    private int remaining(ItemStack s) { return s.getMaxDamage() - s.getDamage(); }

    private int findElytra() {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(Items.ELYTRA) && (!saveElytra.get() || remaining(s) > minDurability.get())) return i;
        }
        return -1;
    }

    private int findChestplate() {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.getItem() instanceof ArmorItem a && a.getType() == ArmorItem.Type.CHESTPLATE) return i;
        }
        return -1;
    }

    /** Envanter indeksi -> ekran slotu; govde slotu (6) ile degistirir */
    private void swapChest(int invIndex) {
        if (invIndex == -1) return;
        var p = mc.player;
        int s = invIndex < 9 ? 36 + invIndex : invIndex;
        mc.interactionManager.clickSlot(0, s, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(0, 6, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(0, s, 0, SlotActionType.PICKUP, p);
        swapCd = 10;
    }

    private boolean useRocket() {
        var p = mc.player;
        var inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                int old = inv.selectedSlot;
                inv.selectedSlot = i;
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                inv.selectedSlot = old;
                return true;
            }
        }
        if (!invFirework.get()) return false;
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                int hb = inv.selectedSlot;
                mc.interactionManager.clickSlot(0, i, hb, SlotActionType.SWAP, p);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                mc.interactionManager.clickSlot(0, i, hb, SlotActionType.SWAP, p);
                return true;
            }
        }
        return false;
    }
}
