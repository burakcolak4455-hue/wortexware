package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.Vec3d;

public class ElytraBooster extends Module {
    public final Setting<Double> speed = register(new Setting<>("Speed", 2.5, 1.0, 6.0));
    public final Setting<Double> smooth = register(new Setting<>("Smooth", 0.5, 0.1, 1.0));

    public ElytraBooster() { super("ElytraBooster", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || !p.isFallFlying()) return;

        // Oyuncuya bagli (yakindaki) bir roket varsa boost aktif
        boolean boosting = !mc.world.getEntitiesByClass(FireworkRocketEntity.class,
                p.getBoundingBox().expand(2.0), e -> true).isEmpty();
        if (!boosting) return;

        Vec3d look = p.getRotationVec(1.0f);
        Vec3d vel = p.getVelocity();
        Vec3d goal = look.multiply(speed.get());
        p.setVelocity(vel.add(goal.subtract(vel).multiply(smooth.get())));
    }
}
