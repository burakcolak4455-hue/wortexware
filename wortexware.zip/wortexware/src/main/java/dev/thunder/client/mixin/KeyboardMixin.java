package dev.thunder.client.mixin;

import dev.thunder.client.ThunderClient;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"))
    private void thunder$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (ThunderClient.modules != null) ThunderClient.modules.onKey(key, action);
    }
}
