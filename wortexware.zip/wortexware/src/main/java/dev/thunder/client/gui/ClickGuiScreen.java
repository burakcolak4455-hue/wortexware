package dev.thunder.client.gui;

import dev.thunder.client.ThunderClient;
import dev.thunder.client.config.Config;
import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.*;

public class ClickGuiScreen extends Screen {
    private static final Map<Category, int[]> POS = new EnumMap<>(Category.class);
    private static final Set<Module> EXPANDED = new HashSet<>();
    private static final Map<Module, Float> ANIM = new HashMap<>();
    private static final int W = 120, HEAD = 20, ROW = 17, SROW = 16, PAD = 4;

    private record Hit(int x, int y, int w, int h, Runnable left, Runnable right, Setting<Double> slider) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private Category dragging;
    private int dragDX, dragDY;
    private Hit sliding;
    private float open; // acilis animasyonu

    public ClickGuiScreen() {
        super(Text.literal("ClickGui"));
        int x = 14;
        for (Category c : Category.values()) {
            POS.putIfAbsent(c, new int[]{x, 14});
            x += W + 8;
        }
    }

    @Override public boolean shouldPause() { return false; }

    private int panelHeight(Category c) {
        int h = HEAD + PAD;
        for (Module m : ThunderClient.modules.modules) {
            if (m.category != c) continue;
            h += ROW;
            if (EXPANDED.contains(m)) h += SROW * m.settings.size();
        }
        return h + PAD;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        open += (1f - open) * 0.2f;
        ctx.fill(0, 0, width, height, ((int) (0x70 * open) << 24));
        hits.clear();
        var tr = textRenderer;

        for (Category c : Category.values()) {
            int[] p = POS.get(c);
            int x = p[0], y = p[1] - (int) ((1f - open) * 12);
            int ph = panelHeight(c);

            RenderUtil.rect(ctx, x, y, W, ph, 6, Theme.BG);
            RenderUtil.rect(ctx, x, y, W, HEAD, 6, Theme.HEADER);
            ctx.fill(x + 6, y + HEAD - 2, x + W - 6, y + HEAD - 1, Theme.accent(c.ordinal()));
            String title = c.name().charAt(0) + c.name().substring(1).toLowerCase();
            ctx.drawText(tr, title, x + (W - tr.getWidth(title)) / 2, y + 6, Theme.TEXT, false);

            int cy = y + HEAD + PAD;
            for (Module m : ThunderClient.modules.modules) {
                if (m.category != c) continue;
                boolean hover = mx >= x && mx < x + W && my >= cy && my < cy + ROW;
                if (hover) RenderUtil.rect(ctx, x + 3, cy, W - 6, ROW, 4, Theme.ROW_HOVER);

                float a = ANIM.getOrDefault(m, 0f);
                a += ((m.isEnabled() ? 1f : 0f) - a) * 0.25f;
                ANIM.put(m, a);

                int nameCol = RenderUtil.lerp(Theme.TEXT_DIM, Theme.TEXT, a);
                ctx.drawText(tr, m.name, x + 9, cy + 5, nameCol, false);

                // switch
                int sx = x + W - 28, sy = cy + 4;
                RenderUtil.rect(ctx, sx, sy, 18, 9, 4, RenderUtil.lerp(Theme.OFF, Theme.accent(cy / 8), a));
                RenderUtil.rect(ctx, sx + 1 + (int) (a * 9), sy + 1, 7, 7, 3, 0xFFFFFFFF);

                if (!m.settings.isEmpty())
                    ctx.drawText(tr, EXPANDED.contains(m) ? "v" : ">", x + W - 38, cy + 5, Theme.TEXT_DIM, false);

                hits.add(new Hit(x, cy, W, ROW, m::toggle,
                        () -> { if (!EXPANDED.remove(m)) EXPANDED.add(m); }, null));
                cy += ROW;

                if (EXPANDED.contains(m)) {
                    for (Setting<?> s : m.settings) {
                        RenderUtil.rect(ctx, x + 3, cy, W - 6, SROW, 3, Theme.SETTING);
                        Object v = s.get();
                        if (v instanceof Boolean b) {
                            ctx.drawText(tr, s.name, x + 9, cy + 4, Theme.TEXT_DIM, false);
                            RenderUtil.rect(ctx, x + W - 24, cy + 4, 8, 8, 2, b ? Theme.accent(cy / 8) : Theme.OFF);
                            Setting<Boolean> sb = (Setting<Boolean>) s;
                            hits.add(new Hit(x, cy, W, SROW, () -> sb.set(!sb.get()), null, null));
                        } else if (v instanceof Double d) {
                            Setting<Double> sd = (Setting<Double>) s;
                            double min = sd.getMin(), max = sd.getMax();
                            float t = (float) ((d - min) / (max - min));
                            ctx.drawText(tr, s.name, x + 9, cy + 2, Theme.TEXT_DIM, false);
                            String val = String.format("%.1f", d);
                            ctx.drawText(tr, val, x + W - 9 - tr.getWidth(val), cy + 2, Theme.TEXT, false);
                            int bx = x + 9, bw = W - 18, by = cy + SROW - 4;
                            RenderUtil.rect(ctx, bx, by, bw, 2, 1, Theme.OFF);
                            RenderUtil.rect(ctx, bx, by, Math.max(2, (int) (bw * t)), 2, 1, Theme.accent(cy / 8));
                            RenderUtil.rect(ctx, bx + (int) (bw * t) - 2, by - 1, 4, 4, 2, 0xFFFFFFFF);
                            hits.add(new Hit(bx, cy, bw, SROW, null, null, sd));
                        }
                        cy += SROW;
                    }
                }
            }
        }
    }

    private void applySlider(Hit h, double mx) {
        Setting<Double> s = h.slider();
        double t = Math.max(0, Math.min(1, (mx - h.x()) / h.w()));
        double v = s.getMin() + t * (s.getMax() - s.getMin());
        s.set(Math.round(v * 10.0) / 10.0);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Category c : Category.values()) {
            int[] p = POS.get(c);
            if (mx >= p[0] && mx < p[0] + W && my >= p[1] && my < p[1] + HEAD && button == 0) {
                dragging = c; dragDX = (int) mx - p[0]; dragDY = (int) my - p[1];
                return true;
            }
        }
        for (Hit h : hits) {
            if (!h.in(mx, my)) continue;
            if (h.slider() != null) { sliding = h; applySlider(h, mx); return true; }
            Runnable r = button == 0 ? h.left() : button == 1 ? h.right() : null;
            if (r != null) r.run();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            int[] p = POS.get(dragging);
            p[0] = (int) mx - dragDX; p[1] = (int) my - dragDY;
            return true;
        }
        if (sliding != null) { applySlider(sliding, mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null; sliding = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == ThunderClient.modules.get("ClickGui").getKey()) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() { Config.save(); }
}
