package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;

public class ClickGui extends Module {
    /** Sohbet ekrani komuttan sonra kapandigi icin menu bir sonraki tick'te acilir */
    public static boolean openRequested;

    public ClickGui() {
        super("ClickGui", Category.RENDER);
        setKey(344); // Right Shift
    }

    @Override
    protected void onEnable() {
        openRequested = true;
        setEnabled(false);
    }
}
