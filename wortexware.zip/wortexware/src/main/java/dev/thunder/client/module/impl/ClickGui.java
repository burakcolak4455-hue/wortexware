package dev.thunder.client.module.impl;

import dev.thunder.client.gui.ClickGuiScreen;
import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;

public class ClickGui extends Module {
    public ClickGui() {
        super("ClickGui", Category.RENDER);
        setKey(344); // Right Shift
    }

    @Override
    protected void onEnable() {
        mc.setScreen(new ClickGuiScreen());
        setEnabled(false); // ekran acilinca modul "kapali" kalsin
    }
}
