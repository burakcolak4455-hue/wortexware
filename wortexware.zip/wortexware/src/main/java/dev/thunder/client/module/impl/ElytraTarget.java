package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class ElytraTarget extends Module {
    public final Setting<Double> range     = register(new Setting<>("Range", 80.0, 5.0, 150.0));
    public final Setting<Double> predict   = register(new Setting<>("Predict", 3.0, 0.0, 10.0));
    public final Setting<Double> turnSpeed = register(new Setting<>("TurnSpeed", 90.0, 1.0, 180.0));
    public final Setting<Boolean> lockMode  = register(new Setting<>("LockMode", true));   // false = Normal (yumusak)
    public final Setting<Boolean> intercept = register(new Setting<>("Intercept", true));  // onune gecme
    public final Setting<Boolean> cling     = register(new Setting<>("Cling", true));      // yakinda hafif yavaslat
    public final Setting<Boolean> sticky    = register(new Setting<>("Sticky", true));
    public final Setting<Boolean> autoHit   = register(new Setting<>("AutoHit", true));
    public final Setting<Double> hitRange  = register(new Setting<>("HitRange", 3.0, 2.0, 6.0));
    public final Setting<Double> delay     = register(new Setting<>("Delay", 0.0, 0.0, 500.0)); // ms

    private PlayerEntity target;
    private long lastHit;

    public ElytraTarget() { super("ElytraTarget", Category.COMBAT); }

    @Override
    protected void onDisable() { target = null; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || !p.isFallFlying()) return;

        if (target != null && (!sticky.get() || !target.isAlive() || target.isRemoved()
                || p.distanceTo(target) > range.get())) target = null;

        if (target == null) {
            double best = Double.MAX_VALUE;
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == p || !e.isAlive() || e.isSpectator()) continue;
                if (Aura.FRIENDS.contains(e.getName().getString().toLowerCase())) continue;
                double d = p.distanceTo(e);
                if (d <= range.get() && d < best) { best = d; target = e; }
            }
        }
        if (target == null) return;

        double dist = p.distanceTo(target);
        Vec3d tv = target.getPos().subtract(new Vec3d(target.prevX, target.prevY, target.prevZ));
        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.6, 0);

        // Onune gecme: kendi hizina gore carpisma suresini hesapla, hedefin gidecegi yere nisan al
        if (intercept.get()) {
            double mySpeed = Math.max(0.5, p.getVelocity().length());
            double t = MathHelper.clamp(dist / mySpeed, 0, 15) * (predict.get() / 3.0);
            aim = aim.add(tv.multiply(t));
        }

        Vec3d to = aim.subtract(p.getEyePos());
        float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0);
        float wantPitch = (float) MathHelper.clamp(-Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z))), -90, 90);
        float max = lockMode.get() ? turnSpeed.get().floatValue() : Math.min(turnSpeed.get().floatValue(), 25f);

        p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - p.getYaw()), -max, max));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(wantPitch - p.getPitch(), -max, max), -90f, 90f));

        // Yaklasinca hizi hafif kis (ustunden gecip kacirmasin)
        if (cling.get() && dist < 6.0) p.setVelocity(p.getVelocity().multiply(0.94));

        if (!autoHit.get() || mc.interactionManager == null) return;
        if (reach(target) > hitRange.get()) return;
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (System.currentTimeMillis() - lastHit < delay.get()) return;

        // Nisan hizalanmadan vurma
        if (p.getRotationVec(1.0f).dotProduct(to.normalize()) < 0.906) return; // ~25 derece

        lastHit = System.currentTimeMillis();
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    private double reach(PlayerEntity e) {
        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        Vec3d c = new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX),
                MathHelper.clamp(eye.y, b.minY, b.maxY), MathHelper.clamp(eye.z, b.minZ, b.maxZ));
        return eye.distanceTo(c);
    }
}
