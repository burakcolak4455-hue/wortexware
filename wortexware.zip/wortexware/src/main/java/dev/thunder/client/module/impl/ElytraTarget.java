package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class ElytraTarget extends Module {
    public final Setting<Double> range = register(new Setting<>("Range", 80.0, 5.0, 150.0));
    public final Setting<Double> predict = register(new Setting<>("Predict", 3.0, 0.0, 10.0));
    public final Setting<Double> turnSpeed = register(new Setting<>("TurnSpeed", 90.0, 1.0, 180.0));
    public final Setting<Boolean> sticky = register(new Setting<>("Sticky", true));
    public final Setting<Boolean> autoHit = register(new Setting<>("AutoHit", true));
    public final Setting<Double> hitRange = register(new Setting<>("HitRange", 3.0, 2.0, 6.0));

    private PlayerEntity target; // kilitli hedef

    public ElytraTarget() { super("ElytraTarget", Category.COMBAT); }

    @Override
    protected void onDisable() { target = null; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || !p.isFallFlying()) return;

        // Sticky: hedef menzildeyse ve canliysa baska birine gecme
        if (target != null && (!sticky.get() || !target.isAlive() || target.isRemoved()
                || p.distanceTo(target) > range.get())) target = null;

        if (target == null) {
            double best = Double.MAX_VALUE;
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == p || !e.isAlive() || e.isSpectator()) continue;
                double d = p.distanceTo(e);
                if (d <= range.get() && d < best) { best = d; target = e; }
            }
        }
        if (target == null) return;

        double dist = p.distanceTo(target);

        // Uzaktayken tahmin yap, yaklasinca tahmini azalt (ustunden gecip kacirmasin)
        double pr = predict.get() * MathHelper.clamp(dist / 20.0, 0.0, 1.0);
        Vec3d vel = target.getPos().subtract(new Vec3d(target.prevX, target.prevY, target.prevZ));
        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.6, 0).add(vel.multiply(pr));
        Vec3d to = aim.subtract(p.getEyePos());

        float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z)));
        float max = turnSpeed.get().floatValue();

        p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - p.getYaw()), -max, max));
        p.setPitch(MathHelper.clamp(
                p.getPitch() + MathHelper.clamp(wantPitch - p.getPitch(), -max, max), -90f, 90f));

        // Menzile girince cooldown dolar dolmaz vur
        if (autoHit.get() && dist <= hitRange.get() && mc.interactionManager != null
                && p.getAttackCooldownProgress(0.5f) >= 1.0f) {
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
