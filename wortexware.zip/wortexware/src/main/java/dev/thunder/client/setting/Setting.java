package dev.thunder.client.setting;

public class Setting<T> {
    public final String name;
    private T value;
    private final T min, max; // sayilar icin, yoksa null

    public Setting(String name, T def) { this(name, def, null, null); }
    public Setting(String name, T def, T min, T max) {
        this.name = name; this.value = def; this.min = min; this.max = max;
    }
    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public T getMin() { return min; }
    public T getMax() { return max; }
}
