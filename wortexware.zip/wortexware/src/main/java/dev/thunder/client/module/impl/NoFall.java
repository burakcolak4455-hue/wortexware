package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class NoFall extends Module {
    public NoFall() { super("NoFall", Category.PLAYER); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p != null && p.fallDistance > 2f && !p.isOnGround())
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
    }
}
