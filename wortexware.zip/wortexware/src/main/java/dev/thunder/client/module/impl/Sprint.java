package dev.thunder.client.module.impl;

import dev.thunder.client.module.Category;
import dev.thunder.client.module.Module;
import dev.thunder.client.setting.Setting;

public class Sprint extends Module {
    public final Setting<Boolean> hungerCheck = register(new Setting<>("HungerCheck", true));

    public Sprint() { super("Sprint", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (hungerCheck.get() && p.getHungerManager().getFoodLevel() <= 6) return;
        if (p.forwardSpeed > 0 && !p.horizontalCollision && !p.isSneaking()) p.setSprinting(true);
    }
}
