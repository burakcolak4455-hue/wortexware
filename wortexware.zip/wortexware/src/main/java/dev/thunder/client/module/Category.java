package dev.thunder.client.module;

public enum Category { COMBAT, MOVEMENT, RENDER, PLAYER, MISC }
