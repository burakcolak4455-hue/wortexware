# WortexWare (Fabric 1.21.1)
Gereksinim: JDK 21, Gradle 8.10+

    gradle wrapper --gradle-version 8.10
    ./gradlew runClient      # test
    ./gradlew build          # build/libs/*.jar

Oyunda: Right Shift = ClickGui | .toggle fly | .bind fly G | .set fly speed 1.5 | .config save/load | .list
Yeni modul: module/impl altina Module'den turet, ModuleManager'a ekle.

## Jar'i GitHub ile derleme (bilgisayara kurulum yok)
1. github.com'da hesap ac, yeni bir repo olustur
2. Bu klasorun icindekileri repoya yukle (.github klasoru dahil)
3. Repoda Actions sekmesi > build calisir (1-3 dk)
4. Bitince calisan isin icinden "wortexware-jar" dosyasini indir
5. Zip icindeki "wortexware-0.1.0.jar" (sources OLMAYAN) dosyasini mods klasorune at
Gereken: Minecraft 1.21.1 + Fabric Loader + Fabric API
